$widget.each(function(index, el) {
  // Простая инициализация виджета
  console.log('HTE Header widget initialized');
}); 
